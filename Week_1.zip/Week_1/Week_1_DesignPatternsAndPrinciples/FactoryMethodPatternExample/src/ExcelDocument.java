public class ExcelDocument implements Document{
    public void open() {
        System.out.println("Open excel doc");
    }
    public void close()
    {
        System.out.println("close excel doc");
    }
}
