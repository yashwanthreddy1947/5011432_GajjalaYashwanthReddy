public class WordDocument implements Document{

        public void open() {
            System.out.println("Open word doc");
        }
        public void close()
        {
            System.out.println("close word doc");
        }
    }


