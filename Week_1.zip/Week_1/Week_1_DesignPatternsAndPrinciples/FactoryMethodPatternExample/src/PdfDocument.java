
    public class PdfDocument implements Document {
        public void open() {
            System.out.println("Open pdf doc");
        }
        public void close()
        {
            System.out.println("close pdf doc");
        }
    }


