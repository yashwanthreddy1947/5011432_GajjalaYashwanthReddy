abstract public class DocumentFactory {
    public abstract Document createDocument();
}






