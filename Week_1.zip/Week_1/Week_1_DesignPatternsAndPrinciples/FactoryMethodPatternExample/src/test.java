public class test {
    public static void main(String args[])
    {
       DocumentFactory wdf=new WordDocumentFactory();
        DocumentFactory pdf=new PdfDocumentFactory();
        DocumentFactory edf=new ExcelDocumentFactory();
       Document w=wdf.createDocument();
        Document p=pdf.createDocument();
        Document e=edf.createDocument();
        w.open();
        w.close();
        p.open();
        p.close();
        e.open();
        e.close();
    }
}
