public class Computer {
    private String processor;
    private float ram;
    private float storage;

    private Computer(Builder builder) {

        this.processor = builder.processor;
        this.ram = builder.ram;
        this.storage = builder.storage;
    }

    public String toString() {
        return "Computer[Processor= " + processor + ", Ram=" + ram + ", Storage= " + storage + "]";
    }

    public static class Builder {
        private String processor;
        private float ram;
        private float storage;

        public Builder setProcessor(String processor) {
            this.processor = processor;
            return this;
        }

        public Builder setRam(float ram) {
            this.ram = ram;
            return this;
        }

        public Builder setStorage(float storage) {
            this.storage = storage;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }

    }


}
