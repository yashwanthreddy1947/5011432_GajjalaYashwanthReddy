public class test {
    public static void main(String[] args) {

        Computer cp = new Computer.Builder().setRam(8).build();
        System.out.println(cp);
    }
}
