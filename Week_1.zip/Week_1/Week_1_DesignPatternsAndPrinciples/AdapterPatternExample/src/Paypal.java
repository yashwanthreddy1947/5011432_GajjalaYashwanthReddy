public class Paypal{
    public void performPayment() {
        System.out.println("paying through paypal");
    }
}
