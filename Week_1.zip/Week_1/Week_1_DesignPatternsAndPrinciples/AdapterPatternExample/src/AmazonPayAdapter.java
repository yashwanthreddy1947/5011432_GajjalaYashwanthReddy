public class AmazonPayAdapter implements PaymentProcessor{

    Amazonpay amazonpay;
    public AmazonPayAdapter( Amazonpay amazonpay)
    {
        this.amazonpay=amazonpay;
    }
    public void processPayment()
    {
        amazonpay.handlePayment();
    }

}
