public class PaypalAdapter implements PaymentProcessor{

    Paypal paypal;
    public PaypalAdapter(Paypal paypal)
    {
        this.paypal=paypal;
    }
    public void processPayment()
    {
        paypal.performPayment();
    }
}
