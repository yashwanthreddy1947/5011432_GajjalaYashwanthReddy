public class test {
    public static void main(String[] args)
    {
        Paypal p=new Paypal();
        Amazonpay a=new Amazonpay();

        PaymentProcessor paypal_adap=new PaypalAdapter(p);
        PaymentProcessor amazonpay_adap=new AmazonPayAdapter(a);

        paypal_adap.processPayment();
        amazonpay_adap.processPayment();


    }
}
