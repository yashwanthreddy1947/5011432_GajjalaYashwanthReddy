public class Amazonpay {
    public void handlePayment()
    {
        System.out.println("Paying through AmazonPay");
    }
}
