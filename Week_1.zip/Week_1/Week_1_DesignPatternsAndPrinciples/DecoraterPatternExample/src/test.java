public class test {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier emailAndSMSNotifier = new SMSNotifierDecorator(new EmailNotifier());
        Notifier emailAndSlackNotifier = new SlackNotifierDecorator(new EmailNotifier());
        Notifier emailSMSAndSlackNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(new EmailNotifier()));



        System.out.println("Sending Email Only:");
        emailNotifier.send("Hello via Email");

        System.out.println("\nSending Email and SMS:");
        emailAndSMSNotifier.send("Hello via Email and SMS");
        System.out.println("\nSending Email and Slack:");
        emailAndSlackNotifier.send("Hello via Email and Slack");

        System.out.println("\nSending Email, SMS, and Slack:");
        emailSMSAndSlackNotifier.send("Hello via Email, SMS, and Slack");

    }
}
