
public abstract class NotifierDecorator implements Notifier {
    protected Notifier nt;

    public NotifierDecorator(Notifier notifier) {
        this.nt = notifier;
    }

    @Override
    public void send(String message) {
        nt.send(message);
    }



}
