public class test {
    public static void main(String[] args) {
        Logger lg1 = Logger.getInstance();
        Logger lg2 = Logger.getInstance();
        lg1.printLoggerNum("I am Logger1");
        lg2.printLoggerNum("I am Logger2");
        System.out.println("Logger id 1 : " + lg1 + "\n" + "Logger id 2 : " + lg2);
        if (lg1 == lg2) {
            System.out.println("Both Loggers have same Loggerid's (instances)");

        } else {
            System.out.println("Both Loggers have different Loggerid's (instances");
        }
    }
}
