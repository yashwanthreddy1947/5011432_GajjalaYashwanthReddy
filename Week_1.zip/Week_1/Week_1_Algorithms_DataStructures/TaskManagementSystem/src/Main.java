public class Main {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();


        taskList.addTask(new Task("T001", "Design Homepage", "In Progress"));
        taskList.addTask(new Task("T002", "Develop API", "Not Started"));
        taskList.addTask(new Task("T003", "Test Application", "In Progress"));
        taskList.addTask(new Task("T004", "Deploy to Production", "Completed"));

        System.out.println("Task List:");
        taskList.traverseTasks();

        System.out.println("\nSearch for Task T003:");
        Task task = taskList.searchTask("T003");
        System.out.println(task != null ? task : "Task not found.");

        System.out.println("\nDelete Task T002:");
        taskList.deleteTask("T002");
        taskList.traverseTasks();
    }
}
