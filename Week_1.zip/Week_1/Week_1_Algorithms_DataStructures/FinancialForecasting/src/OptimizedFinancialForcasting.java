import java.util.HashMap;
import java.util.Map;

public class OptimizedFinancialForcasting {

    // Memoization map to store previously computed future values
    private static Map<Integer, Double> memo = new HashMap<>();

    public static double calculateFutureValue(double initialValue, double growthRate, int periods) {
        // Check if the result is already in the memoization map
        if (memo.containsKey(periods)) {
            return memo.get(periods);
        }

        // Base case: If there are no periods left, return the initial value
        if (periods <= 0) {
            return initialValue;
        }

        double futureValue = calculateFutureValue(initialValue * (1 + growthRate), growthRate, periods - 1);


        memo.put(periods, futureValue);

        return futureValue;
    }

    public static void main(String[] args) {
        double initialValue = 1000.0;
        double growthRate = 0.05;
        int periods = 10;

        double futureValue = calculateFutureValue(initialValue, growthRate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}
