public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order("O001", "Asma", 250.00),
                new Order("O002", "Qamreen", 150.00),
                new Order("O003", "nidhi", 300.00),
                new Order("O004", "harsha", 200.00),
                new Order("O005", "gadepally", 100.00)
        };
        Order[] ordersForBubbleSort = orders.clone();
        Order[] ordersForQuickSort = orders.clone();

        BubbleSort.bubbleSort(ordersForBubbleSort);
        System.out.println("Orders sorted by Bubble Sort:");
        for (Order order : ordersForBubbleSort) {
            System.out.println(order);
        }


        QuickSort.quickSort(ordersForQuickSort, 0, ordersForQuickSort.length - 1);
        System.out.println("\nOrders sorted by Quick Sort:");
        for (Order order : ordersForQuickSort) {
            System.out.println(order);
        }
    }
}
