public class Main {
    public static void main(String[] args) {
        Book[] books = {
                new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald"),
                new Book("B002", "1984", "George Orwell"),
                new Book("B003", "To Kill a Mockingbird", "Harper Lee"),
                new Book("B004", "Pride and Prejudice", "Jane Austen"),
                new Book("B005", "The Catcher in the Rye", "J.D. Salinger")
        };

        Library library = new Library(books);

        System.out.println("Searching for '1984' using linear search:");
        Book bookLinear = library.searchBookByTitleLinear("1984");
        System.out.println(bookLinear != null ? bookLinear : "Book not found.");

        System.out.println("\nSearching for '1984' using binary search:");
        Book bookBinary = library.searchBookByTitleBinary("1984");
        System.out.println(bookBinary != null ? bookBinary : "Book not found.");
    }
}
