public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        // Add employees
        ems.addEmployee(new Employee("E001", "Alice", "Developer", 75000));
        ems.addEmployee(new Employee("E002", "Bob", "Designer", 65000));
        ems.addEmployee(new Employee("E003", "Charlie", "Manager", 85000));
        ems.addEmployee(new Employee("E004", "David", "Analyst", 70000));
        ems.addEmployee(new Employee("E005", "Eve", "Tester", 60000));

        // Traverse employees
        System.out.println("Employee List:");
        ems.traverseEmployees();

        // Search for an employee
        System.out.println("\nSearch for Employee E003:");
        Employee employee = ems.searchEmployee("E003");
        System.out.println(employee != null ? employee : "Employee not found.");


        System.out.println("\nDelete Employee E002:");
        ems.deleteEmployee("E002");
        ems.traverseEmployees();
    }
}
