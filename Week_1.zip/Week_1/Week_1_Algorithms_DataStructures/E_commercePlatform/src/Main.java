import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
                new Product("P001", "Laptop", "Electronics"),
                new Product("P002", "Smartphone", "Electronics"),
                new Product("P003", "Tablet", "Electronics"),
                new Product("P004", "Headphones", "Accessories"),
                new Product("P005", "Smartwatch", "Accessories")
        };

        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        Product foundProductLinear = LinearSearch.linearSearch(products, "P003");
        System.out.println("Linear Search: " + (foundProductLinear != null ? foundProductLinear : "Product not found"));

        Product foundProductBinary = BinarySearch.binarySearch(products, "P003");
        System.out.println("Binary Search: " + (foundProductBinary != null ? foundProductBinary : "Product not found"));
    }
}
